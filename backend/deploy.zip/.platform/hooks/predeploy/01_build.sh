#!/bin/bash
cd /var/app/staging
npm run build
